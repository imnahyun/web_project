package com.myproject.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.myproject.service.UserService;

@Controller
public class UserController {
	@Autowired
	UserService UserService;
	
	@RequestMapping(value="/mypage", method=RequestMethod.GET)
	public ModelAndView mypage(@RequestParam Map<String, Object> map, HttpSession HttpSession){		
		ModelAndView mav = new ModelAndView();		
		List<Map<String,Object>> cartlist = this.UserService.cartlist(map);	
		mav.addObject("amount",cartlist.size());
		mav.addObject("cartlist",cartlist);
		mav.setViewName("/user/mypage");
		return mav;
	}
	@RequestMapping(value="/mypage", method=RequestMethod.POST)
	public ModelAndView mypagePost(@RequestParam Map<String, Object> map, HttpSession HttpSession){		
		ModelAndView mav = new ModelAndView();		
		List<Map<String,Object>> cartlist = this.UserService.cartlist(map);	
		//map.put("amount",cartlist.size());
		String user_id = HttpSession.getAttribute("id").toString();
		mav.addObject("cartlist",cartlist);
		mav.setViewName("redirect:/cart?user_id="+user_id);
		return mav;
	}
	
	@RequestMapping(value="/cart", method=RequestMethod.GET)
	public ModelAndView cart(@RequestParam Map<String, Object> map, HttpSession HttpSession){		
		ModelAndView mav = new ModelAndView();		
		List<Map<String,Object>> cartlist = this.UserService.cartlist(map);	
		mav.addObject("amount",cartlist.size());
		mav.addObject("cartlist",cartlist);
		mav.setViewName("/user/cart");
		return mav;
	}	
	@RequestMapping(value="/cart", method=RequestMethod.POST)
	public ModelAndView cartPost(@RequestParam Map<String, Object> map, HttpSession HttpSession){		
		ModelAndView mav = new ModelAndView();

		String cart_num_string = map.get("cart_num_string").toString();
		List<String> cart_numss = new ArrayList<String>();
		cart_numss = Arrays.asList(cart_num_string.split(","));	
		List<Integer> cartt = new ArrayList<Integer>();		
		for (String string : cart_numss) {
			cartt.add(Integer.parseInt(string));
		}
		map.remove("cart_num_string");
		map.put("cartt", cartt);
		
		mav.addObject("cartt",cartt);
		mav.setViewName("redirect:/myorders");
		HttpSession.setAttribute("mycart", cartt);
		return mav;
	}	
	
	
//	@RequestMapping(value="/myorders", method=RequestMethod.GET)
//	public ModelAndView myorder() {
//		return new ModelAndView("/user/myorders");
//	}	
//	@RequestMapping(value="/myorders", method=RequestMethod.POST)
//	public ModelAndView myorderPost(@RequestParam Map<String,Object> map){
//		ModelAndView mav = new ModelAndView();		
//		List<Map<String,Object>> myorders = this.UserService.cartlist(map); 
//		mav.setViewName("/user/ordering");
//		return mav;
//	}
	
//	@RequestMapping(value="/deletecart")
//	public ModelAndView deletecart(@RequestParam Map<String,Object> map, HttpSession HttpSession) {
//		ModelAndView mav = new ModelAndView(); 
//		int isdelete = this.UserService.deletecart(map);
//		String user_id = HttpSession.getAttribute("id").toString();
//		if(isdelete >= 1)
//			mav.setViewName("redirect:/cart?user_id="+user_id);
//		return mav;
//	}
	
	@RequestMapping(value="/myorders", method=RequestMethod.GET)
	public ModelAndView ordering(@RequestParam Map<String,Object> map, HttpSession HttpSession) {
		ModelAndView mav = new ModelAndView();
		map.put("cartt", HttpSession.getAttribute("mycart"));
		List<Map<String,Object>> orderlist = this.UserService.orderlist(map);		
		mav.addObject("orderlist",orderlist);
		System.out.println(map);
		mav.setViewName("/user/myorders");
		return mav;
	}
	@RequestMapping(value="/myorders", method=RequestMethod.POST)
	public ModelAndView orderingPost(@RequestParam Map<String,Object> map, HttpSession HttpSession) {
		ModelAndView mav = ordering(map,HttpSession);	
		List<Map<String,Object>> ordermap = new ArrayList<Map<String,Object>>();
		ordermap = this.UserService.orderlist(map);
		for (Map<String, Object> items : ordermap) {
			items.put("delivery",map.get("delivery"));
			
			if(map.get("delivery").toString().equals("normal")) {
				items.put("delivery_speed_fee", "0");
			} else if(map.get("delivery").toString().equals("express")) {
				items.put("delivery_speed_fee", "3000");
			}			
			items.put("delivery_location",map.get("delivery_location"));			
			
			items.put("payment_method",map.get("payment_method"));
			if(map.get("payment_method").toString().equals("credit card")) {
				items.put("payment_method_discount", "0.05");
			} else {
				items.put("payment_method_discount", "0");
			}
		}					
		for (Map<String, Object> items2 : ordermap) {
			int isOrdered = this.UserService.ordernow(items2);
			int isDeleted = this.UserService.deletecart(items2);
		}		
		HttpSession.removeAttribute("mycart");
		String user_id = HttpSession.getAttribute("id").toString();
		mav.setViewName("redirect:/mypage?user_id="+user_id);	
		return mav;
	}
}

package com.myproject.controller;
import com.myproject.service.FaqService;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class FaqController {
	@Autowired
	FaqService FaqService;
	
	@RequestMapping(value="/faqlist", method=RequestMethod.GET)
	public ModelAndView faqList(@RequestParam Map<String, Object> map,
			@RequestParam(value="nowPage", required=false) String nowPage){
		ModelAndView mav = new ModelAndView();
//////////////////////////////////////////////////////////////////////////
		double CNT =  2.0; //�� ���� �������� ������ ���� �ǹ�
		int LIMITCOUNT = (int)CNT;
		map.put("skipCount", 0);
		mav.addObject("skipCount",0);
		
		if(nowPage!=null) {
			int now = Integer.parseInt(nowPage);
			int skipCount = 0;
			if(now>1)
				skipCount = (now-1)*LIMITCOUNT;
			map.put("skipCount", skipCount+1);
			mav.addObject("skipCount",skipCount);
		} else {
			map.put("skipCount", 0);
		}

		int totalCount = (int)Math.ceil(this.FaqService.countfaq(map)/CNT);
		mav.addObject("totalCount", totalCount);
	
		int nowPos = nowPage==null?1:Integer.parseInt(nowPage);
		if(nowPos<=0)
			nowPos=1;
		mav.addObject("nowPage",nowPos);

		int endPage = (int)(Math.ceil(nowPos/CNT)*LIMITCOUNT);
		int startPage = 0;
		if(endPage>totalCount) { //���κ�
			startPage = endPage-LIMITCOUNT+1;
			endPage=totalCount;
		} else {
			startPage = endPage-LIMITCOUNT+1;
		}
		if(startPage<=0)
			startPage=1;
		////////////////////////////////////////////
		mav.addObject("startPage",startPage);
		mav.addObject("endPage",endPage);	
		
		List<Map<String,Object>> list = this.FaqService.faqList(map);	
		mav.addObject("faqData",list);			
		mav.setViewName("faq/faqlist");
		return mav;
	}
	
	@RequestMapping(value="/faq_details")
	public ModelAndView faqDetails(@RequestParam Map<String,Object> map) {
		ModelAndView mav=new ModelAndView();
		Map<String,Object> faq = this.FaqService.faqSelectOne(map);
		mav.addObject("faqData", faq);
		String faq_number = map.get("faq_number").toString();
		mav.addObject("faq_number", faq_number);
		mav.setViewName("faq/faq_details");		
		return mav;	
	}
	
	@RequestMapping(value="/faq_create", method=RequestMethod.GET)
	public ModelAndView create(HttpSession HttpSession) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("user_info", HttpSession.getAttribute("signIn"));
		mav.setViewName("faq/faq_create");
		return mav;
	}	
	@RequestMapping(value="/faq_create", method=RequestMethod.POST)
	public ModelAndView createPost(@RequestParam Map<String, Object> map, HttpSession HttpSession) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("user_info", HttpSession.getAttribute("signIn"));
		String number = this.FaqService.createfaq(map);
		if(number == null)
			mav.setViewName("redirect:/faq_create");
		else {
			mav.setViewName("redirect:/faqlist");
		}
		return mav;
	}
	
	
	@RequestMapping(value="faq_edit", method=RequestMethod.GET)
	public ModelAndView update(@RequestParam Map<String, Object> map) {
		Map<String, Object> detailMap = this.FaqService.faqSelectOne(map);
		ModelAndView mav = new ModelAndView();
		mav.addObject("faqData",detailMap);
		mav.setViewName("/faq/faq_edit");
		return mav;
	}
	@RequestMapping(value="faq_edit", method=RequestMethod.POST)
	public ModelAndView updatePost(@RequestParam Map<String, Object> map) {
		ModelAndView mav = new ModelAndView();
		boolean isUpdateSuccess = this.FaqService.editfaq(map);
		if(isUpdateSuccess) {
			String faq_number = map.get("faq_number").toString();
			mav.setViewName("redirect:/faq_details?faq_number="+faq_number);
		} else {
			mav = this.update(map); //���� ȭ������ ���ƿ�
		}
		return mav;
	}
	
	@RequestMapping(value="/faq_delete", method=RequestMethod.POST)
	public ModelAndView deletePost(@RequestParam Map<String,Object> map) {
		ModelAndView mav = new ModelAndView();
		boolean isDeleteSuccess = this.FaqService.removefaq(map);
		if(isDeleteSuccess)
			mav.setViewName("redirect:/faqlist");
		else {
			String faq_number = map.get("faq_number").toString();
			mav.setViewName("redirect:/faq_details?faq_number="+faq_number);
		}
		return mav;
	}
}

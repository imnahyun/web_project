package com.myproject.controller;
import com.myproject.service.LoginService;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {
	@Autowired
	LoginService LoginService;
	
	@RequestMapping(value="/login", method=RequestMethod.GET)
	public ModelAndView login() {
		return new ModelAndView("login/login");
	}	
	@RequestMapping(value="/login", method=RequestMethod.POST)
	public ModelAndView signIn(@RequestParam Map<String,Object> map,HttpServletRequest request) {
		ModelAndView mav = new ModelAndView();
		Map<String,Object> signIn = this.LoginService.signIn(map);

		HttpSession session = request.getSession();
		if(signIn != null) {
			session.setAttribute("signIn", signIn);
			session.setAttribute("id", signIn.get("ID").toString());
			session.setAttribute("pw", signIn.get("PASSWORD").toString());
			mav.setViewName("redirect:/index.jsp");
		}else {
			session.setAttribute("signIn",null);
			mav.setViewName("redirect:/login");
		}
		return mav;
	}

	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/login";
	}
	
	@RequestMapping(value="/signup", method=RequestMethod.GET)
	public ModelAndView signup() {
		return new ModelAndView("login/signup");
	}
	@RequestMapping(value="/signup", method=RequestMethod.POST)
	public ModelAndView signupPost(@RequestParam Map<String,Object> map) {
		ModelAndView mav = new ModelAndView();
		boolean isSuccess = this.LoginService.signUp(map);
		mav.addObject("signUp",isSuccess);
		if(isSuccess) {
			mav.setViewName("redirect:/login");	
		}else {
			mav.setViewName("redirect:/signup");	
		}
		return mav;
	}
	
	@ResponseBody 	
	@RequestMapping(method=RequestMethod.GET, value="/checkId")
	public int idCheck(@RequestParam("id") String id) {	
		int cnt = this.LoginService.checkId(id);
		return cnt;
	}
	
}

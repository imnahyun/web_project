package com.myproject.controller;

import com.myproject.service.ShopService;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

//multiple controller---> @RequestMapping(value="/foldername/*") 
@Controller
public class ShopController {
	
	@Autowired
	ShopService ShopService;
	
	@RequestMapping(value="/products")
	public ModelAndView products(@RequestParam Map<String, Object> map,
			@RequestParam(value="nowPage", required = false) String nowPage) {
		ModelAndView mav = new ModelAndView();
		List<Map<String,Object>> list = this.ShopService.list(map);	
		mav.addObject("data",list);
		
		if(map.containsKey("keyword")) {
			mav.addObject("keyword", map.get("keyword"));
		}	
		mav.setViewName("/products/products");
		return mav;
	}	
	
	@RequestMapping(value="/list")
	public ModelAndView list(@RequestParam Map<String, Object> map,
			@RequestParam(value="nowPage", required = false) String nowPage) {	
		
		List<Map<String,Object>> list = this.ShopService.list(map);	
		ModelAndView mav = new ModelAndView();
		mav.addObject("data",list);

		if(map.containsKey("keyword")) {
			mav.addObject("keyword", map.get("keyword"));
		}	
		mav.setViewName("list");
		return mav;
	}
	
	@RequestMapping(value="/details", method=RequestMethod.GET)
	public ModelAndView details(@RequestParam Map<String, Object> map,HttpSession HttpSession) {
		Map<String, Object> detailMap = this.ShopService.details(map);
		ModelAndView mav = new ModelAndView();
		mav.addObject("data", detailMap);
		mav.addObject("user_info",HttpSession.getAttribute("signIn"));
		String prod_code = map.get("prod_code").toString();
		mav.addObject("prod_code", prod_code);
		mav.setViewName("/products/details");
		return mav;
	}
	
	@RequestMapping(value="/details", method=RequestMethod.POST)
	public ModelAndView detailsPost(@RequestParam Map<String,Object> map, HttpSession HttpSession) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("user_info",HttpSession.getAttribute("signIn"));
		boolean isSuccess = this.ShopService.cartinsert(map);		
		String prod_code = map.get("prod_code").toString();
		mav.setViewName("redirect:/details?prod_code="+prod_code);	
		return mav;
	}

}
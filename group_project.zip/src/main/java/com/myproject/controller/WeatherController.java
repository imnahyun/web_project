package com.myproject.controller;

import com.myproject.service.WeatherService;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class WeatherController {
	@Autowired
	WeatherService WeatherService;
	
	@RequestMapping(value="/weather_info")
	public ModelAndView products(@RequestParam Map<String, Object> map){
		System.out.println("���� ���� ����");
		ModelAndView mav = new ModelAndView();
		Map<String,Object> list = this.WeatherService.SelectWeather(map);
		mav.addObject("data",list);
		mav.setViewName("weather/weather_info");
		return mav;
	}
	
}

package com.myproject.service;

import java.util.List;
import java.util.Map;


public interface FaqService {
	public List<Map<String,Object>> faqList(Map<String,Object> map);
	
	Map<String,Object> faqSelectOne(Map<String,Object> map);
	
	String createfaq(Map<String, Object> map);

	boolean editfaq(Map<String, Object> map);

	boolean removefaq(Map<String, Object> map);
	
	int countfaq(Map<String,Object> map);
}

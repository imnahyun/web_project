package com.myproject.service;
import com.myproject.dao.ShopDAO;

import java.util.List;
import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ShopServiceImpl implements ShopService{	
	@Autowired
	ShopDAO Dao;
	
	@Override
	public List<Map<String,Object>> list(Map<String,Object> map){
		return this.Dao.selectList(map);
	}
	@Override
	public int Count(Map<String,Object> map) {
		return this.Dao.Count(map);
	}
	@Override
	public List<Map<String,Object>> products(Map<String,Object> map){
		return this.Dao.products(map);
	}
	@Override
	public Map<String,Object> details(Map<String,Object> map){
		return this.Dao.details(map);
	}
	
	@Override
	public boolean cartinsert(Map<String,Object> map) {
		return this.Dao.cartinsert(map) == 1;
	}
	
}

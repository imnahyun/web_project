package com.myproject.service;
import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.myproject.dao.LoginDAO;

@Service
public class LoginServiceImpl implements LoginService{
	@Autowired
	LoginDAO Dao;
	
	public Map<String,Object> signIn(Map<String,Object> map){
		return this.Dao.signIn(map);
	}
	
	public boolean signUp(Map<String,Object> map) {
		return this.Dao.signUp(map) == 1;
	}
	
	@Override
	public int checkId(String id) {
		int cnt = this.Dao.checkId(id);
		return cnt;
	}
}

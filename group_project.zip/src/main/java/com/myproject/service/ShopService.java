package com.myproject.service;
import java.util.List;
import java.util.Map;

public interface ShopService {
	public List<Map<String,Object>> list(Map<String,Object> map);
	
	public int Count(Map<String,Object> map);
	
	public Map<String,Object> details(Map<String,Object> map);
	
	public List<Map<String,Object>> products(Map<String,Object> map); 

	public boolean cartinsert(Map<String,Object> map);
}

package com.myproject.service;

import java.util.Map;

public interface WeatherService {
	public Map<String,Object> SelectWeather(Map<String,Object> map);
}

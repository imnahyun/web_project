package com.myproject.service;
import com.myproject.dao.FaqDAO;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FaqServiceImpl implements FaqService{
	@Autowired
	FaqDAO Dao;
	
	@Override
	public List<Map<String,Object>> faqList(Map<String,Object> map){
		return this.Dao.faqList(map);
	}
	
	@Override
	public Map<String,Object> faqSelectOne(Map<String,Object> map){
		return this.Dao.faqSelectOne(map);
	}
	
	@Override
	public String createfaq(Map<String, Object> map) {
		int affectRowCOunt = this.Dao.createfaq(map);
		if(affectRowCOunt==1) {
			return map.get("faq_number").toString();
		}
		return null;
	}

	@Override
	public boolean editfaq(Map<String, Object> map) {
		int affected = this.Dao.editfaq(map);
		return affected == 1; 
	}
	
	@Override
	public boolean removefaq(Map<String, Object> map) {
		int affected = this.Dao.removefaq(map);
		return affected == 1;
	}
	
	@Override
	public int countfaq(Map<String,Object> map) {
		return this.Dao.countfaq(map);
	}
}

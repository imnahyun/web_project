package com.myproject.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myproject.dao.UserDAO;

@Service
public class UserServiceImpl implements UserService{
	@Autowired
	UserDAO Dao;
	

	@Override
	public List<Map<String,Object>> cartlist(Map<String,Object> map){
		return this.Dao.cartlist(map);
	}
	
	@Override
	public int deletecart(Map<String,Object> map) {
		return this.Dao.deletecart(map);
	}
	
	@Override
	public List<Map<String,Object>> orderlist(Map<String,Object> map){
		return this.Dao.orderlist(map);
	}

	@Override
	public int ordernow(Map<String,Object> map) {
		return this.Dao.ordernow(map);
	}
	
}

package com.myproject.service;
import java.util.Map;

public interface LoginService {
	public Map<String,Object> signIn(Map<String,Object> map);
	
	public boolean signUp(Map<String,Object> map);
	
	public int checkId(String id);
}

package com.myproject.service;

import java.util.List;
import java.util.Map;

public interface UserService {
	
	public List<Map<String,Object>> cartlist(Map<String,Object> map);
	
	public int deletecart(Map<String,Object> map);
	
	public List<Map<String,Object>> orderlist(Map<String,Object> map);
	
	public int ordernow(Map<String,Object> map);
}

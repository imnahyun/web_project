package com.myproject.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myproject.dao.WeatherDAO;

@Service
public class WeatherServiceImpl implements WeatherService{
	
	@Autowired
	WeatherDAO Dao;
	
	@Override
	public Map<String,Object> SelectWeather(Map<String,Object> map){
		return this.Dao.SelectWeather(map);
	}
}

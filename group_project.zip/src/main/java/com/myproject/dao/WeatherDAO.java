package com.myproject.dao;

import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class WeatherDAO {
	
	@Autowired
	SqlSessionTemplate SqlSessionTemplate;
	
	public Map<String,Object> SelectWeather(Map<String,Object> map){
		return this.SqlSessionTemplate.selectOne("contents.weather.select_weather", map);
	}
	
}

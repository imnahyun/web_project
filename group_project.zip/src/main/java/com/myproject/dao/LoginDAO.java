package com.myproject.dao;

import java.util.Map;


import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class LoginDAO {
	@Autowired
	SqlSessionTemplate sqlSessionTemplate;
	
	public Map<String,Object> signIn(Map<String,Object> map){
		return this.sqlSessionTemplate.selectOne("contents.login.signin" ,map);
	}
	
	public int signUp(Map<String,Object> map) {
		return this.sqlSessionTemplate.insert("contents.login.signup",map);
	}
	
	public int checkId(String id) {
		return this.sqlSessionTemplate.selectOne("contents.login.isExist",id);
	}
}

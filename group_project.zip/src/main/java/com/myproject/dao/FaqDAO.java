package com.myproject.dao;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

@Repository
public class FaqDAO {
	@Autowired
	SqlSessionTemplate sqlSessionTemplate;
	
	public List<Map<String,Object>> faqList(Map<String,Object> map){
		return this.sqlSessionTemplate.selectList("contents.faq.faqlist" ,map);
	}
	
	public int countfaq(Map<String,Object> map){
		return this.sqlSessionTemplate.selectOne("contents.faq.countfaq",map);
	}
	
	public Map<String,Object> faqSelectOne(Map<String,Object> map){
		return this.sqlSessionTemplate.selectOne("contents.faq.faqselectone",map);
	}

	public int createfaq(Map<String, Object> map) {
		return this.sqlSessionTemplate.insert("contents.faq.insertfaq",map);
	}

	public int editfaq(Map<String, Object> map) {
		return this.sqlSessionTemplate.update("contents.faq.updatefaq",map);
	}

	public int removefaq(Map<String, Object> map) {
		return this.sqlSessionTemplate.delete("contents.faq.deletefaq",map);
	}
}

package com.myproject.dao;

import java.util.List;
import java.util.Map;


import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

@Repository
public class ShopDAO {
	@Autowired
	SqlSessionTemplate sqlSessionTemplate;
	
	public List<Map<String,Object>> selectList(Map<String,Object> map){
		return this.sqlSessionTemplate.selectList("contents.shop.select_list" ,map);
	}

	
	public int Count(Map<String,Object> map) {
		return this.sqlSessionTemplate.selectOne("contents.shop.count",map);
	}
	
	public List<Map<String,Object>> products(Map<String,Object> map){
		return this.sqlSessionTemplate.selectList("contents.shop.select_list",map);
	}
	
	public Map<String,Object> details(Map<String,Object> map){		
		return this.sqlSessionTemplate.selectOne("contents.shop.select_details",map);
	}
	
	
	public List<Map<String,Object>> cartlist(Map<String,Object> map){
		return this.sqlSessionTemplate.selectList("contents.shop.cart_list",map);
	}

	//////////////////////////
	
	public int cartinsert(Map<String,Object> map) {
		return this.sqlSessionTemplate.insert("contents.shop.insertcart",map);
	}
}

package com.myproject.dao;

import java.util.List;
import java.util.Map;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class UserDAO {
	@Autowired
	SqlSessionTemplate SqlSessionTemplate;
	
	public List<Map<String,Object>> cartlist(Map<String,Object> map){
		return this.SqlSessionTemplate.selectList("contents.shop.cart_list",map);
	}
	
	public int deletecart(Map<String,Object> map) {
		return this.SqlSessionTemplate.delete("contents.shop.removecart",map);
	}
	
	public List<Map<String,Object>> orderlist(Map<String,Object> map){
		return this.SqlSessionTemplate.selectList("contents.shop.order_list",map);
	}
	
	public int ordernow(Map<String,Object> map) {
		return this.SqlSessionTemplate.insert("contents.shop.ordernow", map);
	}
}
